import React, { useState, useEffect } from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import { ToastContainer } from "react-toastify";
import RouteComponent from "./routes";
import { useNylas } from '@nylas/nylas-react';

const App = () => {
  const nylas = useNylas();
  const [userId, setUserId] = useState('');
  const SERVER_URI = 'http://localhost:9000';

  useEffect(() => {
    console.log("nylasnylas", nylas)
    if (!nylas) {
      return;
    }

    // Handle the code that is passed in the query params from Nylas after a successful login
    const params = new URLSearchParams(window.location.href);
    console.log(params, 'paramsparams==>>>');
    // debugger
    const code = params.get('code')
    // console.log("paramsparams",code)
    console.log(params.has('code'), 'params.has');
    if (params.has('code')) {
      nylas
        .exchangeCodeFromUrlForToken()
        .then((response) => {
          const user = JSON.parse(response);
          console.log(user, 'useruseruser');
          setUserId(user.id);
          localStorage.setItem('userId', user.id);
          localStorage.setItem('token', user.token); // Jwt token

        })
        .catch((error) => {
          console.error('An error occurred parsing the response:', error);
        });
    }
  }, [nylas]);

  return (
    <div className="app">

      <ToastContainer />

      <RouteComponent />


    </div>
  );
};

export default App;
