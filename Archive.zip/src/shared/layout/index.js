import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import NavBar from "../components/NavBar";

const Layout = (props) => {
  const navigate = useNavigate();
  const userId = localStorage.getItem("userId");

  useEffect(() => {
    if (!!userId) {
      navigate("/");
    }
  }, [userId]);

  return (
    <div className="main-layout">
      <NavBar />
      <div className="inner-layout">{props.children}</div>
    </div>
  );
};

export default Layout;
