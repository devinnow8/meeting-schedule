import React, { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import { Home, Login, Dashboard } from "../pages";
import Layout from "../shared/layout";

const PrivateRoute = ({ children }) => {
  console.log("userroute", localStorage.getItem("userId"));
  const userId = localStorage.getItem("userId");
  if (userId === null) {
    return <Navigate to="/login" />;
  }

  return children;
};

const RouteComponent = () => {

  // useEffect(()=>{
  //   console.log('here callll',window.location.href);
  //   const params = new URLSearchParams(window.location.href);
  //   const code = params.get('code')
  //   console.log("paramsparams",code)

  // },[])


  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={
            <PrivateRoute>
              <Home />
            </PrivateRoute>
          }
          />
          <Route path="/login" element={<Login />} />
          <Route
            path="/dashboard"
            element={
              <PrivateRoute>
                <Dashboard />
              </PrivateRoute>
            }
          />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
};

export default RouteComponent;
