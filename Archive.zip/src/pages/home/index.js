import React, { useState, useEffect } from "react";
import calenderIcon from "../../assets/images/calneder2.png";
import googleCalender from "../../assets/images/google-calendar-1.png";
import gmailIcon from "../../assets/images/gmail.png";
import checkIcon from "../../assets/images/check.png";
import calIcon from "../../assets/images/cal-icon.png";
import { ReactComponent as GoogleIconSvg } from "../../assets/images/google-icon.svg";

const Home = () => {
  const gapi = window.gapi;
  const google = window.google;
  const CLIENT_ID =
    "168070709261-77jstlj3s4hdq75lb6t5jsdurf0jp2iu.apps.googleusercontent.com";
  const API_KEY = "AIzaSyB-iV-p2fiF8KTv_hl5mlO0ADr0XZyhRe0";
  const CALENDER_DISCOVERY_DOC = [
    "https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest",
  ];
  const GMAIL_DISCOVERY_DOC = [
    "https://www.googleapis.com/discovery/v1/apis/gmail/v1/rest",
  ];

  // const SCOPES = "https://www.googleapis.com/auth/calendar";
  const CALENDER_SCOPES = "https://www.googleapis.com/auth/calendar";
  const GMAIL_SCOPES = "https://www.googleapis.com/auth/gmail.readonly";
  const [service, setService] = useState("");
  const accessToken = localStorage.getItem("access_token");
  const expiresIn = localStorage.getItem("expires_in");

  let gapiInited = false,
    gisInited = false,
    tokenClient;

  useEffect(() => {
    if (service !== "") {
      setTimeout(() => {
        handleAuthClick();
      }, 0);
    }
  }, [service]);

  useEffect(() => {
    //const expiryTime = new Date().getTime() + expiresIn * 1000;
    gapiLoaded();
    gisLoaded();
  }, [service]);

  function gapiLoaded() {
    gapi.load("client", initializeGapiClient);
  }

  async function initializeGapiClient() {
    await gapi.client.init({
      apiKey: API_KEY,
      discoveryDocs:
        service === "calender" ? CALENDER_DISCOVERY_DOC : GMAIL_DISCOVERY_DOC,
    });
    gapiInited = true;

    if (accessToken && expiresIn) {
      gapi.client.setToken({
        access_token: accessToken,
        expires_in: expiresIn,
      });
      // getUpcomingEvents();
    }
  }

  function gisLoaded() {
    tokenClient = google.accounts.oauth2.initTokenClient({
      client_id: CLIENT_ID,
      scope: service === "calender" ? CALENDER_SCOPES : GMAIL_SCOPES,
      callback: "", // defined later
    });

    gisInited = true;
  }

  //Enables user interaction after all libraries are loaded.

  function handleAuthClick() {
    tokenClient.callback = async (resp) => {
      if (resp.error) {
        throw resp;
      }
      if (service === "calender") {
        await getUpcomingEvents();
      }
      const { access_token, expires_in } = gapi.client.getToken();
      localStorage.setItem("access_token", access_token);
      localStorage.setItem("expires_in", expires_in);
    };

    if (!(accessToken && expiresIn)) {
      // Prompt the user to select a Google Account and ask for consent to share their data
      // when establishing a new session.
      tokenClient.requestAccessToken({ prompt: "consent" });
    } else {
      // Skip display of account chooser and consent dialog for an existing session.
      tokenClient.requestAccessToken({ prompt: "" });
    }
    setService("");
  }

  async function getUpcomingEvents() {
    let response;
    try {
      const request = {
        calendarId: "primary",
        timeMin: new Date().toISOString(),
        showDeleted: false,
        singleEvents: true,
        maxResults: 10,
        orderBy: "startTime",
      };
      response = await gapi.client.calendar.events.list(request);
    } catch (err) {
      console.log(err.message, "error===>> ");
      return;
    }
    const events = response.result.items;
    console.log(events, "eventseventsevents");
    if (!events || events.length === 0) {
      console.log("NO EVENTS FOUND");
      return;
    }
    // Flatten to string to display
    const output = events.reduce(
      (str, event) =>
        `${str}${event.summary} (${
          event.start.dateTime || event.start.date
        })\n`,
      "Events:\n"
    );
    console.log(output, "List Of Events =====>>>");
  }

  return (
    <>
      <div className="meeting-schedule">
        <div className="container">
          <div className="row">
            <div className="col-md-9">
              <p className="display">Displaying 0-0 of 0 Events</p>
              <div className="meeting-schedule__card">
                <div className="meeting-schedule__header">
                  <ul>
                    <li className="active">New</li>
                    <li>Scheduling</li>
                    <li>Scheduled</li>
                  </ul>
                </div>
                <div className="meeting-schedule__content">
                  <img src={calIcon} className="img-fluid" alt="" />
                  <h5>No Events Yet</h5>
                  <p>Share event type links to schedule events</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="calender-sidebar">
          <div className="calender-sidebar__main">
            <img src={calenderIcon} className="calender-img" alt="" />
            <div className="calender-sidebar__main--btn">
              <div className="google" onClick={() => setService("calender")}>
                {/* <GoogleIconSvg /> */}
                <img src={gmailIcon} alt="" />
                <span className="google-text">Connect your Gmail</span>
              </div>
              <div className="google" onClick={() => setService("gmail")}>
                <img src={googleCalender} alt="" />
                {/* <GoogleIconSvg /> */}
                <span className="google-text">Connect your Calendar</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Home;
