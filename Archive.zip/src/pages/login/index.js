import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useGoogleLogin } from "@react-oauth/google";
import { ReactComponent as GoogleIconSvg } from "../../assets/images/google-icon.svg";
import calenderImg from "../../assets/images/home.png";
import { toast } from "react-toastify";
import PropTypes from 'prop-types';
import { useNylas } from '@nylas/nylas-react';

const Login = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState({});
  const [email, setEmail] = useState();
  const nylas = useNylas();
  const [isLoading, setIsLoading] = useState(false);


 {/* useEffect(() => {
    if (user.access_token !== undefined) {
      axios
        .get(
          `https://www.googleapis.com/oauth2/v1/userinfo?access_token=${user.access_token}`,
          {
            headers: {
              Authorization: `Bearer ${user.access_token}`,
              Accept: "application/json",
            },
          }
        )
        .then((res) => {
          dispatch(
            set_user_details({
              name: res.data.name,
              email: res.data.email,
              id: res.data.id,
              picture: res.data.picture,
            })
          );
          navigate("/");
        })
        .catch((err) => {console.log(err)
          toast.error(err?.response?.data?.error);
        });
    }
  }, [user]);}

  {/*const onLogin = useGoogleLogin({
    onSuccess: (codeResponse) => setUser(codeResponse),
    onError: (error) => {
      console.log("Login Failed:", error)
      toast(error)},
    */}

    const loginUser = (e) => {
      e.preventDefault();
      setIsLoading(true);
  
     
  console.log("nylas", nylas)
      nylas.authWithRedirect({
        emailAddress: email,
        successRedirectUrl: '',
      });
     
    };

    useEffect(() => {
      console.log("nylasnylas",nylas)
      if (!nylas) {
        return;
      }
  
      // Handle the code that is passed in the query params from Nylas after a successful login
      const params = new URLSearchParams(window.location.href);
      console.log("nylas login", nylas);
    
      // debugger
      const code = params.get('code')
      // console.log("paramsparams",code)
  console.log(params.has('code'),'params.has');
      if (params.has('code')) {
        console.log("inside: ");
        nylas
          .exchangeCodeFromUrlForToken()
          .then((response) => {
            const user  = JSON.parse(response);
            console.log(user,'useruseruser');
            // setUserId(user.id);
            localStorage.setItem('userId', user.id);
            localStorage.setItem('token', user.token); // Jwt token
              
          })
          .catch((error) => {
            console.error('An error occurred parsing the response:', error);
          });
      }
    }, [isLoading]); 

  return (
    <section className="signup-hero">
      <div className="container">
        <div className="row">
          <div className="col-md-5">
            <div className="signup-hero__img">
              <img src={calenderImg} alt="" />
            </div>
          </div>
          <div className="col-md-7">
            <div className="signup-hero__content">
              <h1 className="title">
                <span>AI -Powered</span>
                <br /> Automated Scheduling
              </h1>
              <p className="desc">
                Simplify your workload with AI powered automated meeting
                scheduler. Goodbye to manual coordination. Maximize
                productivity. Streamline your calendar
              </p>
              <div className="signup-btn">
                <div className="google" >
                  {/* <GoogleLogin
                  className="h89sdfsf"
                  onSuccess={responseMessage}
                  onError={errorMessage}
                /> */}

                 {/*   <GoogleIconSvg />

                  <span className="google-text">Continue with Google</span>*/}
                  <section className="login">
                  <form onSubmit={loginUser}>
                  <input
                    required
                    type="email"
                    placeholder="Email Address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                  <button type="submit" disabled={isLoading}>
                    {isLoading ? 'Connecting...' : 'Connect email'}
                  </button>
                </form>
                </section>
                </div>
              </div>
            </div>
            {/* <p>OR</p>
            <p className="desc">
              <a href="">Sign up free with email.</a> No credit card required
            </p> */}
          </div>
        </div>
      </div>
    </section>
  );
};


export default Login;
